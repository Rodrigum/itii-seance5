print("Exercice 1:\n")

def cal_tauxvariation(f,a,h):
    tauxvariation=(f(a+h)-f(a))/h
    return tauxvariation


from sympy.utilities.lambdify import lambdify
from sympy.abc import x, y, z

f = lambdify(x, 3*x3 +x2 -5)
a=0
h=1
print(cal_tauxvariation(f,a,h))
f = lambda x : x + 10

print("Exercice 4:\n")

def Find_Sn(n):
    Sn=0
    for i in range(1,n+1):
        Tn=i**2 -(i-1)**2
        Sn=Sn+Tn
    return Sn

print(Find_Sn(3))

print("Exercice 5:\n")

def val_app(epsilon): 
    elm1=1
    elm2=elm1-1/(3**2)
    signe=1
    val=5
    while abs(elm2-elm1)>epsilon:
       elm1=elm2
       elm2=elm1+signe*(1/(val**2))
       val+=2
       signe*=(-1)
    return elm2
 
# tester la fonction
print(val_app(0.05))